import Content from "./content.mdx";

export default function Page() {
  return <Content />;
}
